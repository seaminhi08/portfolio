// 기존 함수 로직은 유지
let isSauceOne = true; 

function switchSauceImage() {
    const imgElement = document.getElementById('sauceImage');
    
    // 요소가 존재하지 않을 때만 함수를 종료합니다. (이 부분은 올바름)
    if (!imgElement) return; 

    if (isSauceOne) {
        // ✨ 수정: 경로를 './../' 에서 '../'로 변경하여 통일
        imgElement.src = '../img2/soy-sauce-2.png';
        imgElement.alt = '두 번째 맛간장 이미지';
        isSauceOne = false;
    } else {
        // 이 경로는 이미 올바릅니다.
        imgElement.src = '../img2/soy-sauce-1.png';
        imgElement.alt = '첫 번째 맛간장 이미지';
        isSauceOne = true;
    }
}
// 💡 DOMContentLoaded 이벤트 연결 부분은 올바릅니다. (유지)
document.addEventListener('DOMContentLoaded', function() {
    const imgElement = document.getElementById('sauceImage');
    if (imgElement) {
        imgElement.addEventListener('click', switchSauceImage);
    }
});