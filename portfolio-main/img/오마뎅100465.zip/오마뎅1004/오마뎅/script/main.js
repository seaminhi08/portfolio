// HTML 문서가 완전히 로드되면 아래의 모든 코드를 실행합니다.
$(document).ready(function () {

    // 기능 1: 물고기 이미지 클릭 시 통통 튀는 애니메이션
    $('.fishs img').on('click', function () {
        // 'is-bouncing' 클래스를 추가해 애니메이션을 실행합니다.
        $(this).addClass('is-bouncing');

        // 애니메이션이 한 번 끝나면, 클래스를 다시 제거합니다.
        // 이렇게 해야 다음에 클릭해도 애니메이션이 반복됩니다.
        $(this).one('animationend', function () {
            $(this).removeClass('is-bouncing');
        });
    });

    // 기능 2: 타임라인 원(.item-circle) 클릭 시 내용 슬라이드
    $('.item-circle').on('click', function () {
        // 클릭된 원의 형제 요소인 '.item-content'를 찾아서
        // 부드럽게 나타나거나 사라지게 합니다.
        $(this).siblings('.item-content').slideToggle();
    });

    // 기능 3: 내비게이션 버튼 클릭 시 'active' 상태 변경 (순수 JavaScript 방식)
    const navButtons = document.querySelectorAll('.nav-button');

    navButtons.forEach(button => {
        button.addEventListener('click', function (event) {
            // a 태그의 기본 동작(페이지 이동 또는 새로고침)을 막습니다.
            event.preventDefault();

            // 모든 버튼에서 'active' 클래스를 먼저 제거하고,
            navButtons.forEach(btn => {
                btn.classList.remove('active');
            });

            // 방금 클릭한 버튼에만 'active' 클래스를 추가합니다.
            this.classList.add('active');
        });
    });

});